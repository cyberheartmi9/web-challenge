<h1>Welcome to SQl injection lab  by <font color="blue">[ @intx0x80 ]</font></h1>
<h2>Try to bypass Filters</h2>
<font color="red"><h1>Try harder</h1></font>

<a href="/Knight-Labs/Websecurity/Sql-injection/level-1.php?id=1">Level 1</a><br>

<a href="/Knight-Labs/Websecurity/Sql-injection/level-2.php?id=1">Level 2</a><br>
<a href="/Knight-Labs/Websecurity/Sql-injection/level-3.php?id=1">Level 3</a><br>
<a href="/Knight-Labs/Websecurity/Sql-injection/level-4.php?id=1">Level 4</a><br>
<a href="/Knight-Labs/Websecurity/Sql-injection/level-5.php?id=1">Level 5</a><br>
<a href="/Knight-Labs/Websecurity/Sql-injection/level-6.php?id=1">Level 6</a><br>
<a href="/Knight-Labs/Websecurity/Sql-injection/level-7.php?id=1">Level 7</a><br>
<a href="/Knight-Labs/Websecurity/Sql-injection/level-8.php?id=1">Level 8</a><br>
<a href="/Knight-Labs/Websecurity/Sql-injection/level-9.php?id=1">Level 9</a><br>


